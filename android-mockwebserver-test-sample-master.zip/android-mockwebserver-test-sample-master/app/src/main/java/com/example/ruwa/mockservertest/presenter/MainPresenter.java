package com.example.ruwa.mockservertest.presenter;

public interface MainPresenter {

    void callService();

}
